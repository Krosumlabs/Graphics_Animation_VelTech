import tkinter as tk

root = tk.Tk()
root.title("My Tkinter Window")
canvas = tk.Canvas(root, width=400, height=400)
canvas.pack()

canvas.create_oval(50, 50, 150, 150, fill="green")

root.mainloop()
