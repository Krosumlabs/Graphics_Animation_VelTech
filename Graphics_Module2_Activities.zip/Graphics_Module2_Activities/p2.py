import pygame
pygame.init()
screen = pygame.display.set_mode((400, 400))
pygame.display.set_caption("Pygame Example")

# Draw a red circle
pygame.draw.circle(screen, (255, 0, 0), (200, 200), 50)

pygame.display.flip()

# Wait for 5 seconds before closing
pygame.time.wait(5000)
pygame.quit()
