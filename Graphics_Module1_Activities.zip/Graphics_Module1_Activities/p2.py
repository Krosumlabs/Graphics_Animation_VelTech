from graphics import *
def main():
    win = GraphWin('My Graphics', 250, 250) # specifies graphics window size 250x250
    g = Point(125, 125) # creates a Point object at x=125 y=125
    g.draw(win) # draws to the graphics window
    win.getMouse() # keep window up
    win.close()
main()