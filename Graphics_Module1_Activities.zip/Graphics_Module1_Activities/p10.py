import pygame

pygame.init()

screen = pygame.display.set_mode((400, 300))
pygame.display.set_caption('Ball Animation')

ball = pygame.Surface((20, 20))
ball.fill((255, 0, 0))
ball_rect = ball.get_rect()
ball_speed = [2, 2]

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    ball_rect = ball_rect.move(ball_speed)
    if ball_rect.left < 0 or ball_rect.right > 400:
        ball_speed[0] = -ball_speed[0]
    if ball_rect.top < 0 or ball_rect.bottom > 300:
        ball_speed[1] = -ball_speed[1]

    screen.fill((0, 0, 0))
    screen.blit(ball, ball_rect)
    pygame.display.flip()
    pygame.time.Clock().tick(60)

pygame.quit()
