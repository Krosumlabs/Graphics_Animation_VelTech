from graphics import *
def main():
  win = GraphWin('My Graphics', 1250, 1250) # specifies graphics window size 250x250
  win.getMouse() # keep window up
  win.close()

main()
