import turtle

# Set up the screen
screen = turtle.Screen()
screen.bgcolor("black")  # Set the background color to black

# Create a turtle
spiral = turtle.Turtle()
spiral.shape("turtle")
spiral.speed(0)  # Fastest drawing speed
spiral.width(2)

# List of colors
colors = ["red", "orange", "yellow", "green", "blue", "purple", "pink"]

# Draw a colorful spiral
for i in range(360):
    spiral.pencolor(colors[i % len(colors)])  # Change color in the list
    spiral.forward(i * 3 / 2 + i)  # Move the turtle forward
    spiral.left(59)  # Turn the turtle left by a fixed angle

# Hide the turtle after drawing
spiral.hideturtle()

# Keep the window open until clicked
screen.exitonclick()
